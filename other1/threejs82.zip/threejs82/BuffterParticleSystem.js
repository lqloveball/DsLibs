﻿
THREE.BufferParticleSystem = function (t, e) {
    var r = t.prefab,
        i = t.count,
        a = t.bounds || new THREE.Vector3(1200, 1200, 1200),
        n = t.side || THREE.FrontSide,
        o = t.idleRotation || !1,
        s = t.movementRange || new THREE.Vector2(0, 0),
        u = t.scale || new THREE.Vector2(1, 1);
    this.transitionDuration = 1, this.prefabCount = i,
    this.bounds = new THREE.Box3,
    this._boundsCenter = new THREE.Vector3, this._boundsSize = a, this.resetBounds();
    var f = this.createGeometry(r, u, s),
        l = new THREE.BufferParticleSystemPhongMaterial({
            shading: THREE.FlatShading,
            side: n,
            idleRotation: o
        }, e);
    // log(f)
    var geometry=f
    var displacement = new Float32Array( geometry.attributes.position.count );
    var noise = new Float32Array( geometry.attributes.position.count );
    geometry.addAttribute( 'displacement', new THREE.BufferAttribute( displacement, 1 ) );
    
    THREE.Mesh.call(this, f, l)
},
THREE.BufferParticleSystem.prototype = Object.create(THREE.Mesh.prototype),
THREE.BufferParticleSystem.prototype.constructor = THREE.BufferParticleSystem,
THREE.BufferParticleSystem.prototype.getRandomPointsInBounds = function (t) {
    for (var e = [], r = 0; t > r; r++) e[r] = new THREE.Vector3(THREE.Math.randFloat(this.bounds.min.x, this.bounds.max.x),
        THREE.Math.randFloat(this.bounds.min.y, this.bounds.max.y), THREE.Math.randFloat(this.bounds.min.z, this.bounds.max.z));
    return e
},
THREE.BufferParticleSystem.prototype.resetBounds = function () {
    this.bounds.setFromCenterAndSize(this._boundsCenter, this._boundsSize)
},
/**
 * [createGeometry description]
 * @param  {[type]} t [prefab ]
 * @param  {[type]} e [scale]
 * @param  {[type]} r [movementRange]
 * @return {[type]}   [description]
 */
THREE.BufferParticleSystem.prototype.createGeometry = function (t, e, r) {
    for (var i = [], a = [], n = t.faces.length, o = 3 * t.faces.length, s = this.prefabVertexCount = t.vertices.length, u = 0; n > u; u++) {
        var f = t.faces[u];
        i.push(f.a, f.b, f.c);
        var l = t.faceVertexUvs[0][u];
        a[f.a] = l[0], a[f.b] = l[1], a[f.c] = l[2]
    }
    var h = new THREE.BufferGeometry,
        E = new Uint32Array(this.prefabCount * o),
        c = new Float32Array(this.prefabCount * s * 3),
        d = new Float32Array(this.prefabCount * s * 3),
        m = new Float32Array(this.prefabCount * s * 2),
        p = new Float32Array(this.prefabCount * s * 3),
        v = new Float32Array(this.prefabCount * s * 3),
        y = new Float32Array(this.prefabCount * s * 3),
        T = new Float32Array(this.prefabCount * s * 3),
        b = new Float32Array(this.prefabCount * s * 2),
        R = new Float32Array(this.prefabCount * s * 3),
        H = new Float32Array(this.prefabCount * s * 2);
    h.addAttribute("index", new THREE.BufferAttribute(E, 1)), h.addAttribute("position", new THREE.BufferAttribute(c, 3)), h.addAttribute("normal", new THREE.BufferAttribute(d, 3)), h.addAttribute("uv", new THREE.BufferAttribute(m, 2)), h.addAttribute("startPosition", new THREE.BufferAttribute(p, 3)), h.addAttribute("controlPoint1", new THREE.BufferAttribute(v, 3)), h.addAttribute("controlPoint2", new THREE.BufferAttribute(y, 3)), h.addAttribute("endPosition", new THREE.BufferAttribute(T, 3)), h.addAttribute("animation", new THREE.BufferAttribute(b, 2)), h.addAttribute("axis", new THREE.BufferAttribute(R, 3)), h.addAttribute("idleAnimation", new THREE.BufferAttribute(H, 2));
    for (var P = 0, g = 0, x = 0, S = 0, A = 0; A < this.prefabCount; A++) {
        for (var _ = new THREE.Vector3(THREE.Math.randFloatSpread(1), THREE.Math.randFloatSpread(1), THREE.Math.randFloatSpread(1)).normalize(), C = THREE.Math.randFloat(0, Math.PI), B = THREE.Math.randFloat(r.x, r.y), w = THREE.Math.randFloat(e.x, e.y), M = 0; s > M; M++) {
            var F = t.vertices[M];
            c[x] = F.x * w, c[x + 1] = F.y * w, c[x + 2] = F.z * w;
            var k = a[M];
            m[g] = k.x, m[g + 1] = k.y, b[g] = 0, b[g + 1] = 1, R[x] = _.x, R[x + 1] = _.y, R[x + 2] = _.z, H[g] = C, H[g + 1] = B, P += 1, g += 2, x += 3, S += 4
        }
        for (var z = 0; o > z; z++) E[A * o + z] = i[z] + A * s
    }
    return h.computeVertexNormals(), h
},
THREE.BufferParticleSystem.prototype.setStartPositions = function (t) {
    if (t.length < this.prefabCount) {
        var e = this.getRandomPointsInBounds(this.prefabCount - t.length);
        t = t.concat(e)
    }
    return this.setAttribute3("startPosition", t), t
},
THREE.BufferParticleSystem.prototype.setEndPositions = function (t) {
    if (t.length < this.prefabCount) {
        var e = this.getRandomPointsInBounds(this.prefabCount - t.length);
        t = t.concat(e)
    }
    return this.setAttribute3("endPosition", t), t
},
THREE.BufferParticleSystem.prototype.setControlPositions = function (t, e) {
    this.setAttribute3("controlPoint1", t), this.setAttribute3("controlPoint2", e)
},
THREE.BufferParticleSystem.prototype.setUvs = function (t) {
    this.setAttribute2("uv", t)
},
THREE.BufferParticleSystem.prototype.setAnimationTiming = function (t, e, r, i) {
    this._durMin = t, this._durMax = e, this._prefabDelay = r,
    this._vertexDelay = i,
    this.transitionDuration = e + this.prefabCount * r + this.prefabVertexCount * i,
    this.bufferAnimation()
},
THREE.BufferParticleSystem.prototype.bufferAnimation = function () {
    for (var t = 0, e = this.geometry.attributes.animation.array, r = 0; r < this.prefabCount; r++)
        for (var i = THREE.Math.randFloat(this._durMin, this._durMax),
            a = r * this._prefabDelay, n = 0; n < this.prefabVertexCount; n++) {
            var o = n * this._vertexDelay;
            e[t++] = a + o, e[t++] = i
        }
    this.geometry.attributes.animation.needsUpdate = !0
},
THREE.BufferParticleSystem.prototype.setAttribute3 = function (t, e) {
    var r, i, a = 0,
        n = this.geometry.attributes[t].array;
    for (r = 0; r < e.length; r++) {
        var o = e[r];
        for (i = 0; i < this.prefabVertexCount; i++) n[a++] = o.x, n[a++] = o.y, n[a++] = o.z
    }
    this.geometry.attributes[t].needsUpdate = !0
},
THREE.BufferParticleSystem.prototype.setAttribute2 = function (t, e) {
    var r, i, a = 0,
        n = this.geometry.attributes[t].array;
    for (r = 0; r < this.prefabCount; r++) {
        var o = e[r];
        for (i = 0; i < this.prefabVertexCount; i++) n[a++] = o.x, n[a++] = o.y
    }
    this.geometry.attributes[t].needsUpdate = !0
},
Object.defineProperty(THREE.BufferParticleSystem.prototype, "transitionTime", {
    get: function () {
        return this.material.uniforms.uTime.value / this.transitionDuration
    }, set: function (t) {
        this.material.uniforms.uTime.value = t * this.transitionDuration
    }
}), Object.defineProperty(THREE.BufferParticleSystem.prototype, "idleTime", {
    get: function () {
        return this.material.uniforms.uIdleTime.value
    },
    set: function (t) {
        this.material.uniforms.uIdleTime.value = t
    }
}),
THREE.BufferParticleSystemPhongMaterial = function (t, e) {
    var r = {
        startPosition: {
            type: "v3",
            value: null
        },
        controlPoint1: {
            type: "v3",
            value: null
        },
        controlPoint2: {
            type: "v3",
            value: null
        },
        endPosition: {
            type: "v3",
            value: null
        },
        animation: {
            type: "v2",
            value: null
        },
        axis: {
            type: "v3",
            value: null
        },
        idleAnimation: {
            type: "v2",
            value: null
        }
    },
        i = {
            uTime: {
                type: "f",
                value: 0
            },
            uIdleTime: {
                type: "f",
                value: 0
            },
            uEaseFactor: {
                type: "f",
                value: .75
            }
        },
        a = {};
    e.map && (a.USE_MAP = ""), e.normalMap && (a.USE_NORMALMAP = ""), t.idleRotation && (a.DO_IDLE_ROTATION = "");
    var n = THREE.ShaderLib.phong,
        o = THREE.UniformsUtils.merge([n.uniforms, i]),
        s = ["varying vec3 vViewPosition;", "#ifndef FLAT_SHADED", "	varying vec3 vNormal;", "#endif", THREE.ShaderChunk.common, THREE.ShaderChunk.map_pars_vertex, THREE.ShaderChunk.lightmap_pars_vertex, THREE.ShaderChunk.envmap_pars_vertex, THREE.ShaderChunk.lights_phong_pars_vertex, THREE.ShaderChunk.color_pars_vertex, THREE.ShaderChunk.morphtarget_pars_vertex, THREE.ShaderChunk.skinning_pars_vertex, THREE.ShaderChunk.shadowmap_pars_vertex, THREE.ShaderChunk.logdepthbuf_pars_vertex, "vec3 rotateVector(vec4 q, vec3 v)", "{", "return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v);", "}", "vec4 quatFromAxisAngle(vec3 axis, float angle)", "{", "float halfAngle = angle * 0.5;", "return vec4(axis.xyz * sin(halfAngle), cos(halfAngle));", "}", "vec3 cubicBezier(vec3 p0, vec3 p1, vec3 c0, vec3 c1, float t)", "{", "vec3 tp;", "float tn = 1.0 - t;", "tp.xyz = tn * tn * tn * p0.xyz + 3.0 * tn * tn * t * c0.xyz + 3.0 * tn * t * t * c1.xyz + t * t * t * p1.xyz;", "return tp;", "}", "float ease(float t, float b, float c, float d, float s) {", "if ((t/=d/2.0) < 1.0) return c/2.0*(t*t*(((s*=(1.525))+1.0)*t - s)) + b;", "return c/2.0*((t-=2.0)*t*(((s*=(1.525))+1.0)*t + s) + 2.0) + b;", "}", "attribute vec3 startPosition;", "attribute vec3 endPosition;", "attribute vec3 controlPoint1;", "attribute vec3 controlPoint2;", "attribute vec2 animation;", "attribute vec3 axis;", "attribute vec2 idleAnimation;", "uniform float uTime;", "uniform float uIdleTime;", "uniform float uEaseFactor;", "void main() {", THREE.ShaderChunk.map_vertex, THREE.ShaderChunk.lightmap_vertex, THREE.ShaderChunk.color_vertex, THREE.ShaderChunk.morphnormal_vertex, THREE.ShaderChunk.skinbase_vertex, THREE.ShaderChunk.skinnormal_vertex, "vec3 tPosition = position;", "float idleOffset = idleAnimation.x;", "float idleMovementRange = idleAnimation.y;", "float idleAngle = uIdleTime + idleOffset;", "float idleTime = sin(idleAngle);", "float idleY = idleTime * idleMovementRange;", "vec4 tQuat = quatFromAxisAngle(axis, idleAngle * 0.5);", "#ifdef DO_IDLE_ROTATION", "   tPosition = rotateVector(tQuat, tPosition);", "#endif", "tPosition.y += idleY;", "float tDelay = animation.x;", "float tDuration = animation.y;", "float tTime = clamp(uTime - tDelay, 0.0, tDuration);", "float tProgress = ease(tTime, 0.0, 1.0, tDuration, uEaseFactor);", "tPosition += cubicBezier(startPosition, endPosition, controlPoint1, controlPoint2, tProgress);", "vec4 mvPosition = modelViewMatrix * vec4(tPosition, 1.0);", "gl_Position = projectionMatrix * mvPosition;", "vViewPosition = -mvPosition.xyz;", THREE.ShaderChunk.morphtarget_vertex, THREE.ShaderChunk.skinning_vertex, "vec3 transformedNormal = normalMatrix * rotateVector(tQuat, normal);", "#ifndef FLAT_SHADED", "	vNormal = normalize( transformedNormal );", "#endif", THREE.ShaderChunk.logdepthbuf_vertex, THREE.ShaderChunk.worldpos_vertex, THREE.ShaderChunk.envmap_vertex, THREE.ShaderChunk.lights_phong_vertex, THREE.ShaderChunk.shadowmap_vertex, "}"].join("\n");
    // log(r);
    THREE.ShaderMaterial.call(this, {
        defines: a,
        attributes: r,
        uniforms: o,
        vertexShader: s,
        fragmentShader: n.fragmentShader,
        lights: !0
    }), this.setValues(t), this.setUniforms(e)
},
THREE.BufferParticleSystemPhongMaterial.prototype = Object.create(THREE.ShaderMaterial.prototype),
THREE.BufferParticleSystemPhongMaterial.prototype.constructor = THREE.BufferParticleSystemPhongMaterial,
THREE.BufferParticleSystemPhongMaterial.prototype.setUniforms = function (t) {
    for (var e in t)
        if (e in this.uniforms) {
            var r = this.uniforms[e],
                i = t[e];
            switch (r.type) {
                case "c":
                    r.value.set(i);
                    break;
                case "v2":
                case "v3":
                case "v4":
                    r.value.copy(i);
                    break;
                case "f":
                case "t":
                    r.value = i
            }
        }
},
Object.defineProperty(THREE.BufferParticleSystemPhongMaterial.prototype, "diffuse", {
    get: function () {
        return this._diffuse
    }, set: function (t) {
        this._diffuse = t, this.uniforms.diffuse.value.set(t)
    }
}), Object.defineProperty(THREE.BufferParticleSystemPhongMaterial.prototype, "emissive", {
    get: function () {
        return this._emissive
    }, set: function (t) {
        this._emissive = t, this.uniforms.emissive.value.set(t)
    }
}), Object.defineProperty(THREE.BufferParticleSystemPhongMaterial.prototype, "specular", {
    get: function () {
        return this._specular
    }, set: function (t) {
        this._specular = t, this.uniforms.emissive.value.set(t)
    }
}), Object.defineProperty(THREE.BufferParticleSystemPhongMaterial.prototype, "shininess", {
    get: function () {
        return this.uniforms.shininess.value
    }, set: function (t) {
        this.uniforms.shininess.value = t
    }
}), Object.defineProperty(THREE.BufferParticleSystemPhongMaterial.prototype, "easeFactor", {
    get: function () {
        return this.uniforms.uEaseFactor.value
    }, set: function (t) {
        this.uniforms.uEaseFactor.value = t
    }
});
