/*个人习惯用log代替console.log来进行简写*/
! (function(window) {
    if (window.log) {
        return
    }
    var slice = [].slice,
    con = window.console;
    function log(type, args) {
        var vs = slice.call(args);
        if (con) {
            con[type].apply ? con[type].apply(con, vs) : con[type](type + ":", vs)
        }
    }
    window.log = function() {
        log("log", arguments)
    }
}(global));

/*开始载入模块*/
exports=module.exports = require('./lib');
//初始化网站端口
exports.Init(8000);
/*
项目结构
SiteApp主程序（SiteModel类实例）
SiteApp.WebApp      项目web服务（express 实现）
SiteApp.Server      项目http服务（http 服务，不需要关心）
SiteApp.IO          项目socket.io服务（socket服务，不需要关心,主要用到封装部分）
SiteApp.BaseServer  项目基础socket服务器逻辑（socket server服务）
                    有服务器连接列表ClientList
SiteApp.GameModel   
 */









