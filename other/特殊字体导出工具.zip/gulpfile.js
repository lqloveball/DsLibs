var fs = require('fs');
var _path = require('path');
var gulp = require('gulp');
var opentype = require('opentype.js');

var _source='方正正大黑简体.TTF'
var font = opentype.loadSync('./source/'+_source);

//获取字体数据信息
gulp.task('fontData', function() {
    var fontData={
        unitsPerEm:font.unitsPerEm,
        descender:font.descender,
        ascender:font.ascender,
    }
    console.log('font Data:',JSON.stringify(fontData));
});

//导出字体
gulp.task('output', function() {
   
    var glyphs=font.glyphs
    console.log('字型数：',glyphs.length)
    var i,l=glyphs.length;
    var glyph,unicodes,unicode,_utn,index,advanceWidth,path;
    var bool=false;
    var _filePath='./bin/'+_source.slice(0,_source.indexOf('.'))+'/';
    _filePath=_path.resolve(process.cwd(), _filePath);
    if (!fs.existsSync(_filePath)) fs.mkdirSync(_filePath);
    var fontData={
        unitsPerEm:font.unitsPerEm,
        descender:font.descender,
        ascender:font.ascender,
    }
    console.log('font Data:',JSON.stringify(fontData));
    for (var i = 0; i < l; i++) {
        glyph=glyphs.get(i);
        index=glyph.index;
        // unicode=glyph.unicode;
        unicodes=glyph.unicodes;
        // if(unicodes[0])unicode=unicodes[0];
        advanceWidth=glyph.advanceWidth;
        path=glyph.path;

        for (var j = 0; j < unicodes.length; j++) {
            unicode=unicodes[j];
            //测试
            if(unicode==20837){
                console.log(index,unicodes,unicode,path.unitsPerEm)
            }
            var _data={
                commands:path.commands,
                unitsPerEm:path.unitsPerEm,
                unicode:unicode,
                advanceWidth:glyph.advanceWidth,
                xMin:glyph.xMin,
                xMax:glyph.xMax,
                yMin:glyph.yMin,
                yMax:glyph.yMax,
                leftSideBearing:glyph.leftSideBearing,
                descender:font.descender,
                ascender:font.ascender,
            }
            var _cmd=JSON.stringify(_data);
            var _file=_filePath+'/'+unicode+'.txt';
            fs.writeFileSync(_file, _cmd);
        }


    }


})